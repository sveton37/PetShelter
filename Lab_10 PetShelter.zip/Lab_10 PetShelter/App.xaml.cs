﻿using System.Windows;

namespace Lab_10_PetShelter
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application { }
}
