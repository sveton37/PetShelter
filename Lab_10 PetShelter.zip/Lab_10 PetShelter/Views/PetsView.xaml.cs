﻿using System.Windows;

namespace Lab_10_PetShelter.Views;

/// <summary>
/// Логика взаимодействия для PetsView.xaml
/// </summary>
public partial class PetsView : Window
{
    public PetsView()
    {
        InitializeComponent();
    }
}