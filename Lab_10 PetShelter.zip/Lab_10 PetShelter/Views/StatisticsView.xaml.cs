﻿using System.Windows;

namespace Lab_10_PetShelter.Views;

public partial class StatisticsView : Window
{
    public StatisticsView()
    {
        InitializeComponent();
    }
}